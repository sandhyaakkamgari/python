my_dict = {"name": "Alice", "age": 30}
del my_dict["age"]  # Deletes the key-value pair with key "age"

print(my_dict)